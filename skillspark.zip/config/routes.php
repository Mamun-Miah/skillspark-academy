<?php
$routes = [
    '' => 'home.php',       
    'about' => 'about.php',
    'contact' => 'contact.php',
    'courses' => 'courses.php',
    'web-development' => 'web-development.php'
];