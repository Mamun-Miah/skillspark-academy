<?php require("./templates/header.php") ?>
  <div class="mt-5 pt-5 herstxt ">
  <h1 class="text-center text-dark fw-bolder mt-5">Web Design & Development</h1>
  </div>

  <div class="container my-5">
    <div class="accordion" id="accordionExample">

      <!--  Module 1-->

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne"
            aria-expanded="true" aria-controls="collapseOne">
            Module 1: Introduction to Web
          </button>
        </h2>
        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <table class="table ">
              <thead>
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Topics</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Software Engineering</td>
                </tr>
                <tr>  
                  <th scope="row">2</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Web Design and Development</td>
                </tr>
                <tr>
                  <th scope="row">3</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>HTML basics</td>
                </tr>
                <tr>
                  <th scope="row">4</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Styling with CSS</td>
                </tr>
                <tr>
                  <th scope="row">5</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>VS code Setup</td>
                </tr>
                <tr>
                  <th scope="row">6</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>GitHub Fundamentals</td>
                </tr>
                <tr>
                  <th scope="row">7</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Bootstrap</td>
                </tr>
                <tr>
                  <th scope="row">8</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Assignment</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>




      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Module 4: Programming in JavaScript

          </button>
        </h2>
        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Topics</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Fundamentals</td>
                </tr>
                <tr>
                  <th scope="row">2</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Dynamic Web Interaction using JavaScript</td>
                </tr>
                <tr>
                  <th scope="row">3</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Object Oriented JavaScript</td>
                </tr>
                <tr>
                  <th scope="row">4</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Exam</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>




      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            Module 5: Programming in PHP
          </button>
        </h2>
        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Topics</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>PHP Fundamentals</td>
                </tr>
                <tr>
                  <th scope="row">2</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Object Oriented Programming</td>
                </tr>
                <tr>
                  <th scope="row">3</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Exam</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
            Module 6: DBMS with SQl
          </button>
        </h2>
        <div id="collapsefour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Topics</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Relational DBMS</td>
                </tr>
                <tr>
                  <th scope="row">2</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>SQL (DDl & DML)</td>
                </tr>
                <tr>
                  <th scope="row">3</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Exam</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
            Module 7: Laravel
          </button>
        </h2>
        <div id="collapsefive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Topics</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Beginning Laravel
                    <ul>
                      <li>Request-Response Model</li>
                      <li>Laravel Components</li>
                    </ul>
                  </td>

                </tr>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Laravel Auth, Cookies, Email, OTP</td>
                </tr>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Laravel Query Builder</td>
                </tr>
                <tr>
                  <th scope="row">2</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Ecommerce Project Development Demonstration</td>
                </tr>
                <tr>
                  <th scope="row">4</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>Project</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="accordion-item">
        <h2 class="accordion-header">
          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix">
            Module 8: The Completion
          </button>
        </h2>
        <div id="collapsesix" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">No.</th>
                  <th scope="col">Date</th>
                  <th scope="col">Time</th>
                  <th scope="col">Topics</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">1</th>
                  <td>1 September 2024</td>
                  <td>5:00 PM-7:00 PM</td>
                  <td>CV and Freelancing</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>

  </div>

  <?php require("./templates/footer.php") ?>