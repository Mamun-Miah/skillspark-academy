<?php require("./templates/header.php") ?>
<div class="mt-5"></div>
<?php require("./templates/allcourses.php") ?>
<?php require("./templates/footer.php") ?>